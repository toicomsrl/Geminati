<?php
switch($modulo){
	case "home":
	$title = "Title";
	$desc = "Description.";
	break; 
    
}?>