<style>
        body{width:100%; overflow-x:hidden; padding:0px; margin:0px;}
        .box-rosso{background:red; padding:100px; text-align:center; color:#fff; font-weight:bold; box-sizing: border-box; margin-bottom:40vh;}
    </style>

    <div class="box-rosso wow flash" data-wow-delay=".3s">flash</div>
    <div class="box-rosso wow shake" data-wow-delay=".3s">shake</div>
    <div class="box-rosso wow bounce" data-wow-delay=".3s">bounce</div>
    <div class="box-rosso wow tada" data-wow-delay=".3s">tada</div>
    <div class="box-rosso wow swing" data-wow-delay=".3s">swing</div>
    <div class="box-rosso wow wobble" data-wow-delay=".3s">wobble</div>
    <div class="box-rosso wow pulse" data-wow-delay=".3s">pulse</div>
    <div class="box-rosso wow flip" data-wow-delay=".3s">flip</div>
    
    <div class="box-rosso wow flipInX" data-wow-delay=".3s">flipInX</div>
    <div class="box-rosso wow flipInY" data-wow-delay=".3s">flipInY</div>
    <div class="box-rosso wow flipOutX" data-wow-delay=".3s">flipOutX</div>
    <div class="box-rosso wow flipOutY" data-wow-delay=".3s">flipOutY</div>    
    
    <div class="box-rosso wow fadeIn" data-wow-delay=".3s">fadeIn</div>
    <div class="box-rosso wow fadeInUp" data-wow-delay=".3s">fadeInUp</div>
    <div class="box-rosso wow fadeInDown" data-wow-delay=".3s">fadeInDown</div>
    <div class="box-rosso wow fadeInLeft" data-wow-delay=".3s">fadeInLeft</div>
    <div class="box-rosso wow fadeInRight" data-wow-delay=".3s">fadeInRight</div>
    
    <div class="box-rosso wow fadeInUpBig" data-wow-delay=".3s">fadeInUpBig</div>
    <div class="box-rosso wow fadeInDownBig" data-wow-delay=".3s">fadeInDownBig</div>
    <div class="box-rosso wow fadeInLeftBig" data-wow-delay=".3s">fadeInLeftBig</div>
    <div class="box-rosso wow fadeInRightBig" data-wow-delay=".3s">fadeInRightBig</div>
    
    <div class="box-rosso wow fadeOut" data-wow-delay=".3s">fadeOut</div>
    <div class="box-rosso wow fadeOutUp" data-wow-delay=".3s">fadeOutUp</div>
    <div class="box-rosso wow fadeOutDown" data-wow-delay=".3s">fadeOutDown</div>
    <div class="box-rosso wow fadeOutLeft" data-wow-delay=".3s">fadeOutLeft</div>
    <div class="box-rosso wow fadeOutRight" data-wow-delay=".3s">fadeOutRight</div>
    
    <div class="box-rosso wow fadeOutUpBig" data-wow-delay=".3s">fadeOutUpBig</div>
    <div class="box-rosso wow fadeOutDownBig" data-wow-delay=".3s">fadeOutDownBig</div>
    <div class="box-rosso wow fadeOutLeftBig" data-wow-delay=".3s">fadeOutLeftBig</div>
    <div class="box-rosso wow fadeOutRightBig" data-wow-delay=".3s">fadeOutRightBig</div>
    
    <div class="box-rosso wow bounceIn" data-wow-delay=".3s">bounceIn</div>
    <div class="box-rosso wow bounceInUp" data-wow-delay=".3s">bounceInUp</div>
    <div class="box-rosso wow bounceInDown" data-wow-delay=".3s">bounceInDown</div>
    <div class="box-rosso wow bounceInLeft" data-wow-delay=".3s">bounceInLeft</div>
    <div class="box-rosso wow bounceInRight" data-wow-delay=".3s">bounceInRight</div>
    
    <div class="box-rosso wow bounceOut" data-wow-delay=".3s">bounceOut</div>
    <div class="box-rosso wow bounceOutUp" data-wow-delay=".3s">bounceOutUp</div>
    <div class="box-rosso wow bounceOutDown" data-wow-delay=".3s">bounceOutDown</div>
    <div class="box-rosso wow bounceOutLeft" data-wow-delay=".3s">bounceOutLeft</div>
    <div class="box-rosso wow bounceOutRight" data-wow-delay=".3s">bounceOutRight</div>
    
    <div class="box-rosso wow rotateIn" data-wow-delay=".3s">rotateIn</div>
    <div class="box-rosso wow rotateInUpLeft" data-wow-delay=".3s">rotateInUpLeft</div>
    <div class="box-rosso wow rotateInDownLeft" data-wow-delay=".3s">rotateInDownLeft</div>
    <div class="box-rosso wow rotateInUpRight" data-wow-delay=".3s">rotateInUpRight</div>
    <div class="box-rosso wow rotateInDownRight" data-wow-delay=".3s">rotateInDownRight</div>
    
    <div class="box-rosso wow rotateOut" data-wow-delay=".3s">rotateOut</div>
    <div class="box-rosso wow rotateOutUpLeft" data-wow-delay=".3s">rotateOutUpLeft</div>
    <div class="box-rosso wow rotateOutDownLeft" data-wow-delay=".3s">rotateOutDownLeft</div>
    <div class="box-rosso wow rotateOutUpRight" data-wow-delay=".3s">rotateOutUpRight</div>
    <div class="box-rosso wow rotateOutDownRight" data-wow-delay=".3s">rotateOutDownRight</div>
    
    <div class="box-rosso wow hinge" data-wow-delay=".3s">hinge</div>
    <div class="box-rosso wow rollIn" data-wow-delay=".3s">rollIn</div>
    <div class="box-rosso wow rollOut" data-wow-delay=".3s">rollOut</div>
    <div class="box-rosso wow lightSpeedIn" data-wow-delay=".3s">lightSpeedIn</div>
    <div class="box-rosso wow lightSpeedOut" data-wow-delay=".3s">lightSpeedOut</div>
    <div class="box-rosso wow wiggle" data-wow-delay=".3s">wiggle</div>