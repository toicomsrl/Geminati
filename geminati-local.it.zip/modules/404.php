<article class="pagina-404">
    <h1>ERRORE 404</h1>
    <h2>Pagina non trovata</h2>
    <img src="<?=$URLASSOLUTO?>img/404.png">
    <h3>Clicca <a href="<?=$URLASSOLUTO?>">QUI</a> per tornare alla home.</h3>
</article>