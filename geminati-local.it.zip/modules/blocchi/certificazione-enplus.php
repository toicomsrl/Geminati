<section class="sect-enplus">
    <div class="contenitore ">
        <h2 class="text-bolder text-white">Qualità e <br>trasparenza con la <br>certificazione ENplus.</h2>
        <a href="<?= $URLASSOLUTO ?>certificazioni/"" class=" btn-freccia">Scopri di più</a>
        <div class="pulizia"></div>
</section>